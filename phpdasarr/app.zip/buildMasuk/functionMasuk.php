<?php
$connect = mysqli_connect("localhost", "root", "", "databarang");
function hapus($id)
{
    global $connect;
    // hapus data ke database barang masuk
    mysqli_query($connect, "DELETE FROM masuk WHERE id = $id");
    return mysqli_affected_rows($connect);
}
